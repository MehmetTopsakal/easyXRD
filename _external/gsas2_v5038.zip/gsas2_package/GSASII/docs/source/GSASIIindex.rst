*GSASIIindex: Cell Indexing Module*
===================================

*Summary/Contents*
----------------------------

Unit cell indexing routines (based on work of A. Coehlo) and
cell refinement from peak positions

.. contents:: Section Contents 

*GSASIIindex routines*
------------------------------------

.. automodule:: GSASIIindex
    :members: 
    :private-members:
    :special-members:

.. only:: html

	  *Indices*
	  ================================

	  `General Index <./genindex.html>`_
	  --------------------------------------------

	  `Module Index <./py-modindex.html>`_
	  --------------------------------------------

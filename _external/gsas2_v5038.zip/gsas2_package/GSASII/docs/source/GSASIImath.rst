*GSASIImath: computation module*
================================

*Summary/Contents*
----------------------------

Least-squares minimization and misc. computation routines. 

.. contents:: Section Contents 

*GSASIImath Classes and routines*
------------------------------------

.. automodule:: GSASIImath
    :members: 
    :private-members:
    :special-members:

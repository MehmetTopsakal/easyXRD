curl -X POST https://readthedocs.org/build/gsas-ii 
echo "Build started"

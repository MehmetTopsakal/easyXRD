# -*- coding: utf-8 -*-
'''
*config.py: Configuration options*
----------------------------------
This file created in SelectConfigSetting on 23 03 2024 14:11
'''

import os.path
import GSASIIpath

Main_Pos = (1280, 0)
'''Main window location - will be updated & saved when user moves
it. If position is outside screen then it will be repositioned to default
'''

Main_Size = (1276, 1572)
'''Main window size (width, height) - initially uses wx.DefaultSize but will updated
 and saved as the user changes the window
'''

Plot_Pos = (108, 80)
'''Plot window location - will be updated & saved when user moves it
these widows. If position is outside screen then it will be repositioned to default
'''

Plot_Size = (1086, 1232)
'''Plot window size (width, height) - initially uses wx.DefaultSize but will updated
 and saved as the user changes the window
'''

